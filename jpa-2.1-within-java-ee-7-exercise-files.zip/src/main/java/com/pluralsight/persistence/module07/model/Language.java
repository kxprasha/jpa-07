package com.pluralsight.persistence.module07.model;

/**
 * @author Antonio Goncalves
 *         http://www.antoniogoncalves.org
 *         --
 */
public enum Language {
  ENGLISH, FRENCH, SPANISH, PORTUGUESE, RUSSIAN, CHINESE, INDIAN, GERMAN, JAPANESE
}